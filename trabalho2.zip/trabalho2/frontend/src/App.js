import logo from './logo.svg';
import './App.css';
import * as Rotas from './routes.js';
import { useEffect, useState } from 'react';
import axios from 'axios'


function App() {

  const participanteDados = {
    nomeDoParticipante:'',
    idadeDoParticipante:''
  }

  const [participantes, setParticipantes] = useState([])
  const [dadosDoParticipantes, setDadosDoParticipantes] = useState(participanteDados)
  const [teste, setTeste] = useState(true)
  const [criacaoOuEdicao, setCriacaoOuEdicao] = useState(true)
  const [armazenaParticipanteParaUpdate, setArmazenaParticipanteParaUpdate] = useState({})


  useEffect(() => {
    fetch("http://localhost:3002/participantes")
      .then(response => response.json())
      .then(response => setParticipantes(response))
  }, [])
  console.log(participantes)
  
  const pegaDadosDoParticipante = (event) => {
    console.log(event.target.name)
    const {name, value} = event.target
    
    setDadosDoParticipantes({...dadosDoParticipantes, [name]: value})
    
  }

  useEffect(() => {
    console.log(dadosDoParticipantes)
  }, [dadosDoParticipantes])

  const adicionaParticipante = () => {
    
    axios.post("http://localhost:3002/participantes", {
      nomeParticipante: dadosDoParticipantes.nomeDoParticipante,
      idadeParticipante: Number(dadosDoParticipantes.idadeDoParticipante)
    })

   fetch("http://localhost:3002/participantes")
    .then(response => response.json())
    .then(response => console.log(response))
    
    window.location.reload()
  }
  
  const deletaParticipante = (itemSelecionado) => {
    // let itemParaDelete = itemSelecionado
    
    
    axios.delete(`http://localhost:3002/participantes/${itemSelecionado.id}`)
    window.location.reload()
  } 

  const updateParticipante = (itemSelecionado) => {
    
    let preDadosDeUpdateParticipante = {
      id: itemSelecionado.id,
      idade: itemSelecionado.idadeParticipante,
      nome: itemSelecionado.nomeParticipante
    }

    console.log(itemSelecionado)
    console.log(preDadosDeUpdateParticipante)
    setArmazenaParticipanteParaUpdate(preDadosDeUpdateParticipante)
    setCriacaoOuEdicao(false)
    
    // axios.put(`http://localhost:3002/participantes`, {

    // })
  }

  const realizandoUpdate = (event) => {
    console.log("Teste")

    const {name, value} = event.target
    
    setArmazenaParticipanteParaUpdate({...armazenaParticipanteParaUpdate, [name]: value})
  }



  useEffect(() => {
    console.log(armazenaParticipanteParaUpdate)
  }, [armazenaParticipanteParaUpdate])

  const salvandoUpdate = () => {
    console.log(armazenaParticipanteParaUpdate)

    axios.put("http://localhost:3002/participantes", armazenaParticipanteParaUpdate)
    
    fetch("http://localhost:3002/participantes")
    .then(response => response.json())
    .then(response => setParticipantes(response))
    .then (reponse => setCriacaoOuEdicao(true))
    window.location.reload()
  }

  const cancelandodoUpdate = () => {  
    setCriacaoOuEdicao(true)
  }

  return (
    <div>

      {criacaoOuEdicao == true ? 
      
          <div className="App">
            <header className="App-header">
              <div className='divHeader'>
                <div>
                  Lista de participantes
                </div>

                <div>
                  Participantes: Davy Brenon RA: 1090481921041                </div>
                
              </div>
              <img src={logo} className="App-logo" alt="logo" />

              <main>
                <h3>Adicione um participante</h3>

                <div className='dadosParticipantes'>
                
                  <input name='nomeDoParticipante' type="text" placeholder="Nome do participante" onChange={(e) => pegaDadosDoParticipante(e)}/>
                  <input name='idadeDoParticipante' type="number" placeholder="Idade do participante" onChange={(e) => pegaDadosDoParticipante(e)}/>

                  <button className='botaoAdiciona' onClick={() => adicionaParticipante()}>Adcionar participantes</button>

                </div>

                <div className='tabelaDeParticipante'>
                  <table>
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Participante</th>
                        <th>Idade</th>
                        <th>Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      {participantes.map((itemSelecionado, i) => {
                        return (
                          <tr>
                            <th>{i + 1}</th>
                            <td>{itemSelecionado.nomeParticipante}</td>
                            <td>{itemSelecionado.idadeParticipante}</td>
                            <td>
                              <button
                                type="button"
                                className="inputDaQntPorItem"
                                onClick={() => deletaParticipante(itemSelecionado)}
                              >
                                Excluir
                              </button>

                              <button
                                type="button"
                                className="inputDaQntPorItem"
                                onClick={() => updateParticipante(itemSelecionado)}
                              >
                                Editar
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </main>

            </header>
          <Rotas.Routes />
          
        </div>
      
      : <div>
          <div className="App">
            <header className="App-header">
              <div className='divHeader'>
                <div>
                  Lista de participantes
                </div>

                <div>
                  Sobre nós
                </div>
                
              </div>
              <img src={logo} className="App-logo" alt="logo" />

              <main >
                
                <h3>Edição do participante</h3>
                <div className='centralizaEdicao'>

                  <input name='nome' placeholder={armazenaParticipanteParaUpdate.nome} onChange={(e) => realizandoUpdate(e)}></input>
                  <input name='idade'placeholder={armazenaParticipanteParaUpdate.idade} onChange={(e) => realizandoUpdate(e)}></input>
                  
                  <button onClick={() => cancelandodoUpdate()}>Cancelar</button> 
                  <button onClick={() => salvandoUpdate()}>Salvar</button> 
                </div>
              </main>

            </header>
          <Rotas.Routes />
          
        </div>
        </div>}
    </div>
    
  );
}

export default App;
