import React from 'react'
import {BrowserRouter, Route, Switch} from 'react-router-dom'




export function Routes() {
  
  return(
    <BrowserRouter>
    <Switch>
        <Route path='/dashboard' exact  />
        <Route path='/dashboard/cadastrarPedidos' exact  />      
    </Switch>
  </BrowserRouter>
  )

}








// eslint-disable-next-line import/no-anonymous-default-export

