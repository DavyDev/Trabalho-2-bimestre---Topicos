// const ProdutosPedidos = require('..//models/produtosPedidos')
// const Pedidos = require('../models/pedidos')

const Participantes = require("../models/participantes");

class Participantestroller {

   

    async ListandoParticipantes(req, res, next) {
        const listagemDosParticipantes = await Participantes.findAll()
        res.json(listagemDosParticipantes)
    }
    
    async AdicionandoParticipantes(req, res, next) {
        console.log(req.body)
        const adicionaOsParticipantes = await Participantes.create({
            nomeParticipante: req.body.nomeParticipante,
            idadeParticipante: req.body.idadeParticipante,
        })
       
    }

    async DeletandoParticipantes(req, res, next) {
        console.log(req.params)
        const deletaOsParticipantes = await Participantes.destroy({
            where: {
                id: req.params.id
            }
        })
        res.json(deletaOsParticipantes)
    }
    
    async UpdateDeParticipantes(req, res, next) {
        console.log(req.body)
        let trataBody = {
            nomeParticipante: req.body.nome,
            idadeParticipante: req.body.idade
        }
        const deletaOsParticipantes = await Participantes.update(trataBody, {
            where: {
                id: req.body.id
            }})
        res.json(deletaOsParticipantes)
    }
}
 
module.exports =  new Participantestroller();
