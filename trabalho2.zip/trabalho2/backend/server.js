const app = require('./config/configApplication')
const port = 3002 //Porta que o servidor estará escultando
const bodyParser = require("body-parser")
const express = require('express')
const urlencodedParser = bodyParser.urlencoded({ extended: false })

const cors = require('cors')

app.use(cors());
app.use(bodyParser.json())

const pedidosRouter = require("./src/routes/pedidosRouter")

app.use('/', pedidosRouter)

app.listen(port, () => {
    console.log(`Servidor executando na porta ${port}`)
})