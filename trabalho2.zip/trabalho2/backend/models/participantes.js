const Sequelize = require('sequelize')
const db = require('./db')

const Participantes = db.define('participantes', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    nomeParticipante:{
        type: Sequelize.STRING,
        allowNull: false
    },
    idadeParticipante: {
        type: Sequelize.INTEGER,
        allowNull: false
    }
});

//Criar a tabelano bando de dados
Participantes.sync()

//Verifica se háalguma diferença na tabela, e realiza a alteração
// Participantes.sync({ alter: true })

module.exports = Participantes;