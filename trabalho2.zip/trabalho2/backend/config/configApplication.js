const express = require('express')


const app = express() // instanciando o servidor express


module.exports = app
